# remember to start this server with  uvicorn main:app --reload --host 0.0.0.0 --port 8000

from fastapi import FastAPI
from pydantic import BaseModel
from igdbclient import IGDBClient
from starlette.middleware.cors import CORSMiddleware

app = FastAPI()

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # Allows all origins, change this if needed
    allow_credentials=True,
    allow_methods=["*"],  # Allows all HTTP methods
    allow_headers=["*"],  # Allows all headers
)

class NameRequest(BaseModel):
    name: str



# Replace these with your actual credentials
client_id = 'chxawvc6ihkixiq1trn5kjenh9cavm'
client_secret = 'w7tyvuosembzb62awb0gww80oosvc3'

# Instantiate the IGDBClient
igdb = IGDBClient(client_id, client_secret)

# Refresh the access token
igdb.refresh_token()





@app.get("/")
async def read_root():
    return {"Hello": "World (v2)"}

@app.get("/search")
async def get_games():
    return {"error": "this is a post-only endpoint"}


@app.post("/search")
async def get_games(request: NameRequest):
    # Log the search results to inspect
    search_results = igdb.get_game_matches(request.name)
    print("Search Results:", search_results)
    
    detailed_games = []
    for game_name in search_results:
        game_info = igdb.get_game_info(game_name)
        print(f"Game Info for {game_name}:", game_info)
        
        if game_info:
            game_details = game_info[0]
            game_name = game_details.get('name', 'Unknown')
            game_rating = game_details.get('rating', 'N/A')
            game_cover = game_details.get('cover', None)
            game_platforms = game_details.get('platforms', [])
            game_genres = game_details.get('genres', [])

            detailed_games.append({
                "name": game_name,
                "rating": game_rating,
                "cover": game_cover,
                "platforms": game_platforms,
                "genres": game_genres,
            })

    return {"Matches": detailed_games}



@app.get("/get-info")
async def get_info():
    return {"error": "this is a post-only endpoint"}


@app.post("/get-info")
async def get_info(request: NameRequest):
    game_name = request.name
    game_info = igdb.get_game_info(game_name)

    game = game_info[0]

    game_id = game.get('id')
    game_name = game.get('name')
    game_rating = game.get('rating')
    game_rating_count = game.get('rating_count')
    
    genre_ids = game.get('genres', [])

    completion_time_in_seconds = igdb.get_completion_time(game_id)

    if type(genre_ids) is int:
        tmp = genre_ids
        genre_ids = [tmp]

    if genre_ids:
        genres = igdb.get_genres(genre_ids)
        print("Genres:", genres)
    else:
        print("Genres: None")



    platform_ids = game.get('platforms', [])

    if type(platform_ids) is int:
        tmp = platform_ids
        platform_ids = [tmp]

    if platform_ids:
        platforms = igdb.get_platforms(platform_ids)
        print("Platforms:", platforms)
    else:
        print("Platforms: None")


    cover_ids = game.get('cover', [])
    if type(cover_ids) is int:
        tmp = cover_ids
        cover_ids = [tmp]

    if cover_ids:
        covers = igdb.get_covers(cover_ids)
        print("Covers:", covers)
    else:
        print("Covers: None")
    # https://images.igdb.com/igdb/image/upload/t_cover_big/{cover_id}.webp

    return {"id": game_id,
            "name": game_name,
            "rating": game_rating,
            "rating_count": game_rating_count,
            'genres': genres,
            'platforms': platforms,
            'cover': covers[0],
            'comp_time_in_secs': completion_time_in_seconds}