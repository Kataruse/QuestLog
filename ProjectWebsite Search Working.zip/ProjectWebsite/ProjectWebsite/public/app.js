const searchInput = document.getElementById('search-bar');
const gameListDiv = document.getElementById('gameList');

// Debounce timer
let debounceTimer;

// Function to handle search input and display games
function handleInput() {
    // Clear the previous debounce timer if the user is still typing
    clearTimeout(debounceTimer);

    // Set a new debounce timer
    debounceTimer = setTimeout(() => {
        const query = searchInput.value;
        if (!query) return;

        // Fetch game matches from the backend
        fetch(`http://127.0.0.1:8000/search`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ name: query }),
        })
        .then(response => response.json())
        .then(data => {
            displayGameResults(data.Matches);
        })
        .catch(error => {
            console.error('Error fetching games:', error);
            gameListDiv.innerHTML = '<p>Error fetching results. Try again later.</p>';
        });
    }, 500); // Wait 500ms after the user stops typing before searching
}

// Function to display the search results
function displayGameResults(games) {
    gameListDiv.innerHTML = ''; // Clear previous results
    if (games.length === 0) {
        gameListDiv.innerHTML = '<p>No games found.</p>';
        return;
    }

    games.forEach(game => {
        const gameDiv = document.createElement('div');
        gameDiv.className = 'game-item';

        // Game Name (Clickable)
        const gameTitle = document.createElement('h3');
        gameTitle.innerText = game.name;
        gameDiv.appendChild(gameTitle);

        // Dropdown Button to show game details
        const detailsButton = document.createElement('button');
        detailsButton.innerText = 'Show Details';
        gameDiv.appendChild(detailsButton);

        // Details Section (Initially Hidden)
        const detailsDiv = document.createElement('div');
        detailsDiv.className = 'game-details';
        detailsDiv.style.display = 'none'; // Initially hidden
        detailsDiv.innerHTML = `
            <p><strong>Rating:</strong> ${game.rating === 'N/A' ? 'No Rating Available' : game.rating}</p>
            <p><strong>Platforms:</strong> ${game.platforms.join(', ')}</p>
            <p><strong>Genres:</strong> ${game.genres.join(', ')}</p>
        `;

        // Ensure the cover ID is correctly prefixed with 'co' and build the image URL
        if (game.cover) {
        const coverUrl = `https://images.igdb.com/igdb/image/upload/t_cover_big/${game.cover}.webp`;
        

        // Log the cover URL for debugging
        console.log('Cover URL:', coverUrl);

        // Create the cover image element
        const coverArt = document.createElement('img');
        coverArt.src = coverUrl;
        coverArt.alt = `${game.name} Cover Art`;
        coverArt.style.width = '150px';  // Adjust the size

        // Fallback in case the image doesn't load
        coverArt.onerror = () => {
            console.error('Could not find image:', coverUrl);
            coverArt.src = 'https://via.placeholder.com/150';  // Placeholder image
            coverArt.alt = 'No cover art available';
        };

        detailsDiv.appendChild(coverArt);  // Append the image
        } else {
            const noCoverText = document.createElement('p');
            noCoverText.innerText = 'No cover art available.';
            detailsDiv.appendChild(noCoverText);
        }

        gameDiv.appendChild(detailsDiv);

        // Toggle details visibility when button is clicked
        detailsButton.addEventListener('click', () => {
            if (detailsDiv.style.display === 'none' || detailsDiv.style.display === '') {
                detailsDiv.style.display = 'block';
                detailsButton.innerText = 'Hide Details';
            } else {
                detailsDiv.style.display = 'none';
                detailsButton.innerText = 'Show Details';
            }
        });

        // Append the game div to the game list
        gameListDiv.appendChild(gameDiv);
    });
}